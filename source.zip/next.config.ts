import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  basePath: "/tiktok-program-manager-portfolio",
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
