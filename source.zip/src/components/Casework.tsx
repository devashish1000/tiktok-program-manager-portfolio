import sampleResults from "../../public/sample/results.json";
import { ArrowRight, Plus } from "@phosphor-icons/react/dist/ssr";
import { liveSample, type CasePoint } from "@/data/casework";
import { whyLive, roleNote, type Story } from "@/data/content";

function Points({ items }: { items: CasePoint[] }) {
  return <dl className="brief-points">{items.map(item => <div key={item.title}><dt>{item.title}</dt><dd>{item.detail}</dd></div>)}</dl>;
}

export function StoryBrief({ story }: { story: Story }) {
  const rows: [string, string][] = [
    ["The problem", story.problem],
    ["The constraint", story.constraint],
    ["What I owned", story.owned],
    ["Who I aligned", story.aligned],
    ["The decision", story.decision],
  ];
  return <div className="story-brief">
    <dl className="brief-rows">{rows.map(([term, detail]) => <div key={term}><dt>{term}</dt><dd>{detail}</dd></div>)}</dl>
    <div className="brief-result"><p className="small-label">The result</p><p>{story.result}</p></div>
    <div className="brief-limit"><p className="small-label">What I would not overclaim</p><p>{story.limit}</p></div>
  </div>;
}

export function LiveSample() {
  return <section className="live-sample shell" id="live-sample" tabIndex={-1} aria-labelledby="sample-title">
    <div className="sample-heading"><div><p className="small-label">Hypothetical work sample</p><h2 id="sample-title">When reviewer<br />decisions diverge.</h2></div><div className="sample-disclosure"><strong>Independent illustrative analysis</strong><p>Not TikTok work, internal processes, or a past project. No employer or production outcomes are claimed.</p></div></div>
    <div className="sample-scenario"><h3>The scenario</h3><p>{liveSample.scenario}</p></div>
    <div className="sample-principle"><span>My starting point</span><p>Address potential harm first. Validate the signal before broader rollout changes.</p></div>

    <div className="case-brief" aria-labelledby="synthetic-title">
      <div className="brief-opening"><p className="small-label">Executed analysis · Synthetic data</p><h3 id="synthetic-title">A reproducible review-quality example.</h3><p>120 invented review records. These computed results describe the fixture only; they are not employer outcomes or proof of causality.</p></div>
      <div className="brief-columns"><div><h4>Computed disagreement</h4><p><strong>{sampleResults.totals.baseline.disagreements}/{sampleResults.totals.baseline.reviewed} → {sampleResults.totals.rollout.disagreements}/{sampleResults.totals.rollout.reviewed}</strong> · +{sampleResults.change_pp} percentage points</p><ul>{sampleResults.strata.map(row => <li key={row.workflow}>{row.workflow}: {row.baseline.disagreements}/{row.baseline.reviewed} → {row.rollout.disagreements}/{row.rollout.reviewed}</li>)}</ul><p>All additional disagreements occur in the appeals stratum. Equal-sized strata are not a representative production sample; site and workflow effects cannot be separated.</p></div><div><h4>Capacity and proposed decision</h4><p>The assumed appeals follow-up queue needs {sampleResults.capacity[0].required_minutes} minutes against {sampleResults.capacity[0].available_minutes} available: a {sampleResults.capacity[0].shortfall_minutes}-minute gap.</p><p>Propose specialist review of escalation flags and targeted investigation before wider appeals rollout. No pause, staffing change, or policy action has been executed.</p></div></div>
      <p className="contact-links"><a href="/tiktok-program-manager-portfolio/sample/complete-analysis.zip" download>Download complete analysis</a><a href="/tiktok-program-manager-portfolio/sample/README.md">Decision brief &amp; reproduction</a><a href="/tiktok-program-manager-portfolio/sample/reviews.csv" download>Review CSV</a><a href="/tiktok-program-manager-portfolio/sample/capacity.csv" download>Capacity CSV</a><a href="/tiktok-program-manager-portfolio/sample/analyze.py" download>Python analysis</a><a href="/tiktok-program-manager-portfolio/sample/check_expected.py" download>Expected checks</a><a href="/tiktok-program-manager-portfolio/sample/results.json" download>Computed JSON</a><a href="/tiktok-program-manager-portfolio/sample/results.md">Results table</a></p>
    </div>
    <details className="sample-details"><summary>Read the LIVE quality decision brief <Plus size={20} aria-hidden="true" /></summary><div className="sample-expanded">
      <section><h3>Objective &amp; assumptions</h3><p className="sample-objective">{liveSample.objective}</p><Points items={liveSample.assumptions} /></section>
      <section><h3>How I would prioritize</h3><ol className="decision-steps">{liveSample.priorities.map(point => <li key={point.title}><h4>{point.title}</h4><p>{point.detail}</p></li>)}</ol></section>
      <section><h3>Measure quality and capacity together</h3><Points items={liveSample.metrics} /></section>
      <section><h3>When I would escalate</h3><Points items={liveSample.escalation} /></section>
      <section><h3>AI supports analysis. People own decisions.</h3><Points items={liveSample.aiApproach} /></section>
      <section><h3>Decision checkpoints</h3><Points items={liveSample.checkpoints} /></section>
      <p className="sample-deliverable">{liveSample.outcome}</p>
      <p className="brief-source-note">Independent hypothetical sample · Proposed approach only · No platform data or achieved production outcomes</p>
    </div></details>
  </section>;
}

export function WhyLive() {
  return <section className="why-live shell" id="why-live" tabIndex={-1} aria-labelledby="why-live-title">
    <div className="section-label-row"><p className="small-label">Why LIVE</p><span>{roleNote}</span></div>
    <div className="why-heading">
      <h2 id="why-live-title">{whyLive.heading}</h2>
      <p>{whyLive.intro}</p>
    </div>
    <ol className="mapping-list">{whyLive.rows.map((row, i) => <li key={i}>
      <div className="map-side map-from">
        <p className="small-label">What I have run</p>
        <p className="map-text">{row.from}</p>
        <p className="map-proof">{row.proof}</p>
      </div>
      <div className="map-arrow" aria-hidden="true"><ArrowRight size={20} /></div>
      <div className="map-side map-to">
        <p className="small-label">What it maps to on LIVE</p>
        <p className="map-text">{row.to}</p>
      </div>
    </li>)}</ol>
    <div className="why-gaps">
      <h3>What does not transfer, and what I would do about it.</h3>
      <Points items={whyLive.gaps} />
      <p className="brief-source-note">{whyLive.disclaimer}</p>
    </div>
  </section>;
}
