import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  icons: { icon: "/tiktok-program-manager-portfolio/favicon.svg" },
  title: "Dev Neupane — Program Delivery & Trust and Safety",
  description: "Policy implementation, review quality, and cross-functional program delivery in a user-generated-content integrity environment — mapped to the TikTok LIVE Ecosystem program manager role.",
  metadataBase: new URL("https://devashish1000.github.io/tiktok-program-manager-portfolio/"),
  alternates: { canonical: "https://devashish1000.github.io/tiktok-program-manager-portfolio/" },
  openGraph: {
    title: "Dev Neupane — Program Delivery & Trust and Safety",
    description: "Clear policy. Consistent decisions. Stronger operations.",
    type: "website",
    url: "https://devashish1000.github.io/tiktok-program-manager-portfolio/",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><a className="skip-link" href="#main">Skip to content</a>{children}</body></html>;
}
