export type CasePoint = { title: string; detail: string };
export type CaseMetric = { value: string; label: string; detail: string };

// Historical achievement claims are user-confirmed, not independently audited.
export const linkedinCase: {
  eyebrow: string;
  title: string;
  summary: string;
  context: string;
  accountability: string;
  actions: CasePoint[];
  collaboration: CasePoint[];
  results: CaseMetric[];
  boundary: string;
} = {
  eyebrow: "Selected experience / LinkedIn",
  title: "Turning policy into consistent operations",
  summary: "Owned the rollout of six policy updates across five global sites and twelve review workflows.",
  context: "The rollout covered policy implementation across multiple sites and review workflows.",
  accountability: "Owned the rollout, defining operating procedures, reviewer guidance, and escalation criteria.",
  actions: [
    { title: "Operating procedures", detail: "Defined operating procedures for implementation across the twelve review workflows." },
    { title: "Reviewer guidance", detail: "Defined reviewer guidance for the six policy updates." },
    { title: "Escalation criteria", detail: "Defined escalation criteria as part of the rollout." },
  ],
  collaboration: [
    { title: "Rollout reach", detail: "The policy rollout spanned five global sites." },
    { title: "Separate program experience", detail: "Also owned eight operational improvement initiatives across Trust & Safety Operations, Policy, Engineering, and Data Science, coordinating twenty stakeholders across five sites on requirements, dependencies, and readiness. This is separate from the policy-rollout results below." },
  ],
  results: [
    { value: "98%", label: "Implementation adherence", detail: "Within 60 days." },
    { value: "25%", label: "Fewer policy-related review errors", detail: "Reported outcome of the policy rollout." },
  ],
  boundary: "A selected work summary. The cross-functional initiatives are separate experience, not additional outcomes attributed to this policy rollout.",
};

export const liveSample: {
  eyebrow: string;
  title: string;
  disclosure: string;
  scenario: string;
  objective: string;
  assumptions: CasePoint[];
  priorities: CasePoint[];
  metrics: CasePoint[];
  escalation: CasePoint[];
  aiApproach: CasePoint[];
  checkpoints: CasePoint[];
  outcome: string;
} = {
  eyebrow: "Independent work sample / Hypothetical",
  title: "When reviewer decisions diverge",
  disclosure: "An independently authored hypothetical approach for a livestream platform. This is not TikTok work, an account of a past project, or a description of TikTok's internal processes. No results have been achieved or measured for this sample.",
  scenario: "During a hypothetical policy rollout, a quality review signals rising disagreement between reviewers. Before expanding the rollout, the program owner needs to determine whether the signal reflects ambiguous guidance, uneven implementation, or a change in case mix.",
  objective: "Clarify the source of disagreement and support a documented rollout decision while protecting users and maintaining operational capacity.",
  assumptions: [
    { title: "Comparable review data", detail: "Assume approved access to de-identified cases, policy-version labels, reviewer decisions, and site or workflow context. If comparable data are unavailable, resolve that limitation before claiming a trend." },
    { title: "Defined decision authority", detail: "Assume an accountable policy owner can interpret policy and an operations owner can approve rollout changes. The program owner coordinates the evidence, dependencies, and decision record." },
    { title: "No preset threshold", detail: "Baseline performance, sampling uncertainty, risk tolerance, and operational constraints must be established with the responsible owners. No numerical target is assumed here." },
  ],
  priorities: [
    { title: "First: potential harm", detail: "Triage disagreements that may create serious user harm or materially inconsistent enforcement for prompt specialist review. Risk comes before raw case volume." },
    { title: "Then: validate the signal", detail: "Compare like-for-like policy versions, case categories, and review conditions. Inspect the sampling method and case mix before attributing the change to the rollout." },
    { title: "Then: isolate the cause", detail: "Review a stratified sample with qualified policy and quality partners. Separate unclear guidance, implementation differences, and cases needing policy interpretation; keep unresolved cases explicit." },
    { title: "Choose a bounded response", detail: "If guidance ambiguity is supported, propose a clarification for the affected workflow and a limited validation step. If evidence is inconclusive, expand the review before a broad intervention. Avoid a platform-wide change based on a local or noisy signal." },
  ],
  metrics: [
    { title: "Reviewer agreement", detail: "Matching decisions divided by eligible independently double-reviewed cases, using a fixed decision taxonomy. Report sample size, exclusions, and segment mix. Agreement alone does not establish correctness." },
    { title: "Adjudicated error rate", detail: "Incorrect decisions divided by cases adjudicated against the applicable policy by qualified reviewers. Record unresolved cases separately and acknowledge that an escalated sample may not represent all decisions." },
    { title: "Implementation adherence", detail: "Audited eligible reviews following the required version-specific procedure divided by audited eligible reviews. Distinguish procedural adherence from decision correctness." },
    { title: "Operational guardrails", detail: "Track backlog age and SLA attainment using agreed case eligibility and time windows. Review these alongside quality so an intervention does not conceal delayed reviews or a shifting workload." },
  ],
  escalation: [
    { title: "Potential serious harm", detail: "Route credible high-risk cases through the approved urgent escalation process. Ask the accountable owner whether the affected rollout segment should pause; do not wait for a routine aggregate report." },
    { title: "Policy interpretation", detail: "Escalate conflicting interpretations to the policy owner with de-identified examples, the relevant version, and the unresolved question. Do not let a majority vote substitute for policy interpretation." },
    { title: "Quality or capacity deterioration", detail: "Escalate sustained deterioration against agreed baseline and guardrails, or inability to implement a correction within available capacity. Present targeted pause, correction, and further sampling options with their constraints." },
  ],
  aiApproach: [
    { title: "Assist analysis", detail: "With approved tooling and data access, use AI to suggest clusters of de-identified disagreement reasons and draft summaries. Do not use generated labels as adjudicated truth or allow the tool to make enforcement decisions." },
    { title: "Validate with people", detail: "Have qualified reviewers validate a stratified sample of suggested labels, including uncertain and high-risk cases. Record corrections, inspect missed themes, and expand human review when reliability is insufficient." },
    { title: "Protect the decision record", detail: "Keep source references and human corrections traceable; use only permitted data in approved tools. Treat model output as an analytical aid, and retain accountable human approval for policy and rollout decisions." },
  ],
  checkpoints: [
    { title: "Before intervention", detail: "Agree on case eligibility, baseline, decision owners, uncertainty, and quality/capacity guardrails. Record the diagnosis and the evidence still missing." },
    { title: "After a limited correction", detail: "Re-review comparable cases and assess agreement, adjudicated errors, and operational guardrails. Check whether the suspected cause actually changed before expanding the correction." },
    { title: "At the rollout decision", detail: "Present proceed, hold, or revise options to the accountable owner. Record the rationale, open risks, owners, and next review trigger; continued uncertainty is a reason to qualify the decision." },
  ],
  outcome: "Proposed deliverable: a concise decision brief with the validated signal, diagnosis, options, recommended action, accountable owners, and follow-up measures. This sample demonstrates an approach, not an achieved result.",
};

