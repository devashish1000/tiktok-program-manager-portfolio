// Achievement metrics are user-confirmed; they have not been independently audited.
// Every claim on this site maps to a bullet on the résumé. Nothing here claims livestream,
// creator-economy, or monetization product experience.

export const recruiterIntro =
  "I turn enforcement policy into procedures a review team can actually run, read case-level review and appeal outcomes as an ecosystem signal, and hold cross-functional delivery when capacity will not cover the plan. At LinkedIn I owned that work for twelve workflows reviewing member-generated posts, comments, and profiles across five global sites.";

export const roleNote = "Prepared for Program Manager, TikTok LIVE Ecosystem · Job A4513 · Los Angeles";

export type Story = {
  company: string;
  title: string;
  summary: string;
  metric: string;
  metricLabel: string;
  briefLabel: string;
  problem: string;
  constraint: string;
  owned: string;
  aligned: string;
  decision: string;
  result: string;
  limit: string;
};

export const stories: Story[] = [
  {
    company: "LinkedIn",
    title: "Turning policy into practice",
    summary:
      "I translated enforcement requirements for member-generated posts, comments, and profiles into procedures, reviewer guidance, and escalation criteria.",
    metric: "98%",
    metricLabel: "implementation adherence within 60 days",
    briefLabel: "Read the policy rollout brief",
    problem:
      "Six enforcement policy updates had to take effect across five global sites and twelve workflows reviewing member-generated posts, comments, and profiles. A published policy is not an implemented one: reviewers needed to know what changed at the moment of a decision.",
    constraint:
      "Five sites with different tenure and case mixes moving to the same standard inside the same window, without pausing live review queues.",
    owned:
      "The operating procedures, reviewer guidance, and escalation criteria for each rollout, and the adherence checks that showed whether the change had actually landed.",
    aligned:
      "Policy for interpretation, Trust & Safety Operations for reviewer readiness and queue impact, Engineering and Data Science for the tooling and measurement each change depended on.",
    decision:
      "Treat a rollout as incomplete until the procedure, the guidance, and the escalation path existed and an owner was named for ambiguous cases — rather than announcing the policy and correcting afterwards.",
    result: "98% implementation adherence within 60 days; policy-related review errors down 25%.",
    limit:
      "I implemented policy; I did not author it. Adherence measures whether the required procedure was followed, which is not the same as whether each individual decision was correct.",
  },
  {
    company: "LinkedIn",
    title: "Improving review quality",
    summary:
      "I separated unclear guidance from genuine policy edges from uneven implementation, then routed each finding to the team that could correct it.",
    metric: "86% → 95%",
    metricLabel: "reviewer agreement in two quarters",
    briefLabel: "Read the review-quality brief",
    problem:
      "Review errors were visible case by case, but it was not clear which were reviewer mistakes, which came from unclear guidance, and which were genuine policy edges that no procedure covered yet.",
    constraint:
      "Roughly 10,000 review decisions and appeals per quarter across five sites. Nothing close to that volume can be re-adjudicated, and agreement between reviewers cannot by itself establish who was right.",
    owned:
      "The quality program: what was sampled, how disagreements were categorized, and how findings became specific corrections with named owners.",
    aligned:
      "Policy owned interpretation of contested cases. Operations owned reviewer guidance, training, and queue changes. I owned the evidence, the corrections list, and the follow-through.",
    decision:
      "Route findings by cause rather than by volume — guidance clarifications to Operations, interpretation questions to Policy — so each correction landed with whoever could actually make it.",
    result: "Repeat errors down 30%; reviewer agreement from 86% to 95% in two quarters.",
    limit:
      "Reviewer agreement measures consistency between reviewers, not correctness; it should be read alongside adjudicated error, not in place of it. I am not attributing the improvement to any single corrective action.",
  },
  {
    company: "Southwest Airlines",
    title: "Coordinating operational delivery",
    summary:
      "I owned a performance-improvement program and set corrective priorities from measured operational signal rather than from the loudest request.",
    metric: "92%",
    metricLabel: "milestones delivered on schedule",
    briefLabel: "Read the operational-delivery brief",
    problem:
      "A performance-improvement program spanning 100+ cost centers had more candidate work than the organization could execute, with Finance, Commercial, and Technical teams each holding part of the answer.",
    constraint:
      "Competing functional priorities, no single owner with authority over all three groups, and savings that had to survive Finance review to count.",
    owned:
      "The program: intake, the prioritized initiative list, milestone and dependency tracking, and the weekly exception review where corrective priorities were set.",
    aligned:
      "Finance, Commercial, and Technical leads across twelve prioritized initiatives; separately, 240 requests across eighteen locations with defined severity, owners, and escalation paths.",
    decision:
      "Prioritize against measured operational signal — 15+ KPIs, trends, and variance drivers surfaced in weekly reviews — and make the deferred work explicit rather than silent.",
    result:
      "92% of milestones on schedule and $1.2M in annualized operating savings; 95% on-time completion on tracked requests and overdue actions down 43%.",
    limit:
      "This is operations and cost work, not Trust & Safety. It is here as evidence of running prioritization and delivery across functions that do not report to me — not as content-ecosystem experience.",
  },
];

export type MapRow = { from: string; proof: string; to: string };

export const whyLive = {
  heading: "What I ran at LinkedIn, and what it maps to on LIVE.",
  intro:
    "LinkedIn Trust & Safety is not livestream. The surface is different and I will not pretend otherwise. The operating problem this role describes — policy into procedure, case-level signal into ecosystem recommendation, quality held against capacity — is the one I have already run.",
  rows: [
    {
      from: "Converted enforcement requirements for member-generated posts, comments, and profiles into operating procedures, reviewer guidance, and escalation criteria across twelve workflows and five global sites.",
      proof: "6 policy rollouts · 98% implementation adherence within 60 days · policy-related review errors down 25%",
      to: "Best practices and procedures for a livestream ecosystem team: a policy or product change is not shipped until the procedure, the reviewer guidance, and the escalation path exist, and someone is named to answer the ambiguous cases.",
    },
    {
      from: "Ran a review-quality program over 10,000 review decisions and appeals per quarter, separating unclear guidance from genuine policy edges from uneven implementation.",
      proof: "Repeat errors down 30% · reviewer agreement 86% → 95% in two quarters",
      to: "Synthesizing case-level observations into ecosystem recommendations: reading individual outcomes as a pattern, and telling the team which part of the pattern is guidance, which is policy, and which is execution.",
    },
    {
      from: "Owned capacity planning for twelve Trust & Safety workflows built from policy changes, case forecasts, and reviewer productivity; replanned a rollout when capacity threatened implementation quality.",
      proof: "Higher-risk workflows prioritized; lower-risk changes deferred until training and acceptance checks were complete",
      to: "Using data to set priorities under constraint: sizing the review demand a policy or format change will create, and sequencing a rollout where quality would break first rather than where it is easiest.",
    },
    {
      from: "Owned eight cross-functional initiatives with twenty stakeholders across Trust & Safety Operations, Policy, Engineering, and Data Science, with weekly updates and decision briefs to Operations and Policy leadership.",
      proof: "95% of milestones delivered on time",
      to: "Driving cross-functional alignment and managing initiatives to on-time delivery with the partner set this role names, and writing the decision record leadership can act on.",
    },
    {
      from: "Coordinated eight vendors across six service categories through escalation paths, resolution targets, and weekly aging-exception reviews (Allen & Overy); built operational dashboards and ran weekly exception reviews over 15+ KPIs (Southwest Airlines).",
      proof: "Vendor resolution time 8 → 5 business days · reporting cycle time down 60%",
      to: "Coordinating partner constraints and running the reporting, review, and quality mechanisms an ecosystem team depends on — including AI-assisted triage where a qualified person still owns the enforcement decision.",
    },
  ] as MapRow[],
  gaps: [
    {
      title: "Real-time enforcement",
      detail:
        "My review experience is asynchronous. Content persists, and a decision can be revisited before most harm compounds. A live broadcast does not wait. I would expect procedures, escalation thresholds, and staffing math to be tighter and far less forgiving, and I would learn that from the people running it before proposing changes.",
    },
    {
      title: "Creator monetization integrity",
      detail:
        "I have not worked on gifting, incentives, or monetization abuse. Incentive-driven abuse has failure modes my policy-implementation work does not cover, and I would treat it as something to learn rather than something I already have.",
    },
    {
      title: "Scale and velocity of a global video surface",
      detail:
        "Five sites and twelve workflows is not TikTok's volume. What transfers is the method for sizing demand and sequencing a rollout, not an assumption that the numbers behave the same way at this scale.",
    },
    {
      title: "How I would close the gap",
      detail:
        "First weeks: decision owners, the operational signals the team already trusts, where review demand originates, and which partner and vendor constraints bound the calendar. Then one recurring quality or procedure gap taken end to end with the accountable owners, and used to set how we distinguish a promising signal from a validated improvement.",
    },
  ],
  disclaimer:
    "I have not worked on livestream, creator-economy, or monetization products. Nothing on this page claims LIVE experience. It states the operating practices I have run elsewhere and where I judge they apply.",
};

export const experience = [
  {
    company: "Bellevue University",
    role: "Software Engineer",
    dates: "Jul 2026 - Present",
    achievement: "Own requirements-to-release delivery across three application and data enhancements with six stakeholders; delivered in eight weeks against agreed acceptance criteria and dependencies, and reduced processing time 25%.",
  },
  {
    company: "Southwest Airlines",
    role: "Senior Performance Analyst, Corporate Analytics",
    dates: "Apr 2023 - May 2024",
    achievement: "Owned a performance-improvement program across 100+ cost centers and intake and escalation paths for 240 requests across eighteen locations; 92% of milestones on schedule and 95% on-time completion.",
  },
  {
    company: "LinkedIn",
    role: "Senior Business Analyst, Planning & Optimization",
    dates: "Nov 2020 - Mar 2023",
    achievement: "Owned six policy rollouts, the review-quality program over 10,000 decisions and appeals per quarter, capacity planning for twelve Trust & Safety workflows, and eight cross-functional initiatives with twenty stakeholders across five global sites.",
  },
  {
    company: "Allen & Overy",
    role: "Business Analyst, Finance & Business Management",
    dates: "Jan 2020 - Nov 2020",
    achievement: "Led transition readiness across eight vendors and 85 critical milestones, and reviewed aging vendor exceptions weekly across six service categories; average resolution time fell from eight to five business days.",
  },
  {
    company: "NYC Department of Education",
    role: "Finance & Budget Analyst, Business Management",
    dates: "Aug 2019 - Dec 2019",
    achievement: "Presented three priority tiers across $1B+ in capital proposals to make sequencing explicit, and standardized submissions and validation across 220+ sites; incomplete or inconsistent submissions fell 40%.",
  },
];

export const headwell = {
  name: "HeadWell",
  category: "Side project",
  title: "Co-Founder, Product & Analytics",
  dates: "Dec 2025 - Present",
  location: "Remote",
  summary: "Owned the roadmap and delivery from concept to TestFlight, coordinating product and engineering partners.",
  scope: "Translated 25 user interviews into twelve requirements and coordinated product and engineering partners through three release checkpoints, delivering the initial TestFlight release in ten weeks.",
  contribution: "Led release quality across eight user journeys and prioritized seventeen TestFlight findings, documenting severity and owners for each finding and resolving all release blockers.",
  outcome: "Improved task completion from 76% to 93% across two testing rounds.",
  feedback: "Used AI-assisted classification for 500 feedback items with human validation, routing uncertain classifications to manual review before prioritization; reduced triage time 30% and shortened feedback-to-decision time from seven to three days.",
  note: "Personal project built outside employment. Included as evidence of release delivery and AI-assisted analysis with human validation — not as Trust & Safety or professional product experience.",
};
