// Achievement metrics are user-confirmed; they have not been independently audited.
export const recruiterIntro = "At LinkedIn, I owned eight initiatives across Trust & Safety Operations, Policy, Engineering, and Data Science.";

export const programEvidence = {
  company: "LinkedIn",
  label: "Cross-functional program ownership",
  summary: "Eight initiatives across Trust & Safety Operations, Policy, Engineering, and Data Science; 95% of milestones delivered on time.",
  metric: "8",
  metricLabel: "cross-functional initiatives owned",
};

export const stories = [
  {
    company: "LinkedIn",
    title: "Turning policy into practice",
    summary: "I owned the rollout of six policy updates and defined operating procedures, reviewer guidance, and escalation criteria.",
    metric: "98%",
    metricLabel: "implementation adherence within 60 days",
    scope: "Six policy updates across five global sites and twelve review workflows.",
    contribution: "I defined the operating procedures, reviewer guidance, and escalation criteria used in the rollout.",
    outcome: "Achieved 98% implementation adherence within 60 days and reduced policy-related review errors 25%.",
  },
  {
    company: "LinkedIn",
    title: "Improving review quality",
    summary: "I identified enforcement gaps and coordinated corrective actions with Policy and Operations.",
    metric: "86% → 95%",
    metricLabel: "reviewer agreement in two quarters",
    scope: "Quality analysis of 10,000 review decisions and appeals each quarter.",
    contribution: "I identified systemic enforcement gaps in review decisions and appeals, then coordinated corrective actions with Policy and Operations.",
    outcome: "Improved reviewer agreement from 86% to 95% in two quarters and reduced repeat errors 30%.",
  },
  {
    company: "Southwest Airlines",
    title: "Coordinating operational delivery",
    summary: "I owned a performance-improvement program and aligned Finance, Commercial, and Technical teams on delivery.",
    metric: "92%",
    metricLabel: "milestones delivered on schedule",
    scope: "A performance-improvement program across 100+ cost centers and twelve prioritized initiatives.",
    contribution: "I owned the program and aligned Finance, Commercial, and Technical teams on the twelve prioritized initiatives.",
    outcome: "Delivered 92% of milestones on schedule and $1.2M in annualized operating savings.",
  },
];

export const experience = [
  {
    company: "Bellevue University",
    role: "Software Engineer",
    dates: "Jul 2026 - Present",
    achievement: "Delivered three application and data enhancements in eight weeks, using agreed acceptance criteria and dependencies; reduced processing time 25%.",
  },
  {
    company: "Southwest Airlines",
    role: "Senior Performance Analyst, Corporate Analytics",
    dates: "Apr 2023 - May 2024",
    achievement: "Owned intake and escalation paths for 240 requests across eighteen locations; achieved 95% on-time completion.",
  },
  {
    company: "LinkedIn",
    role: "Senior Business Analyst, Planning & Optimization",
    dates: "Nov 2020 - Mar 2023",
    achievement: "Coordinated twenty stakeholders across five sites on requirements, dependencies, and readiness for eight initiatives.",
  },
  {
    company: "Allen & Overy",
    role: "Business Analyst, Finance & Business Management",
    dates: "Jan 2020 - Nov 2020",
    achievement: "Reviewed aging vendor exceptions weekly across six service categories; average resolution time fell from eight to five business days.",
  },
  {
    company: "NYC Department of Education",
    role: "Finance & Budget Analyst, Business Management",
    dates: "Aug 2019 - Dec 2019",
    achievement: "Standardized submissions and validation across 220+ sites, assigning named owners to exceptions; incomplete or inconsistent submissions fell 40%.",
  },
];

export const headwell = {
  name: "HeadWell",
  category: "Project",
  title: "Co-Founder, Product & Analytics (Project)",
  dates: "Dec 2025 - Present",
  location: "Remote",
  summary: "Owned the roadmap and delivery from concept to TestFlight, coordinating product and engineering partners.",
  scope: "Translated 25 user interviews into twelve requirements and coordinated product and engineering partners through three release checkpoints, delivering the initial TestFlight release in ten weeks.",
  contribution: "Led release quality across eight user journeys and prioritized seventeen TestFlight findings, documenting severity and owners for each finding and resolving all release blockers.",
  outcome: "Improved task completion from 76% to 93% across two testing rounds.",
  feedback: "Used AI-assisted classification for 500 feedback items with human validation, routing uncertain classifications to manual review before prioritization; reduced triage time 30% and shortened feedback-to-decision time from seven to three days.",
};
