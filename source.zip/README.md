# Dev Neupane — dedicated Program Manager portfolio

A separate Next.js static-export portfolio for program delivery and Trust & Safety opportunities. The original `devashish1000/devashish1000.github.io` repository and deployment are not modified.

The approved audit improvements are included: LinkedIn ownership in the hero, visible responsibilities in work summaries, a factual quality-program brief, program/capacity context, a clearly hypothetical independent LIVE decision sample, and larger accessible controls. Historical work and hypothetical analysis are kept separate.

## Local development

Requires Node.js 24 and pnpm 11.19.0.

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Open `http://localhost:3000/tiktok-program-manager-portfolio/`.

```sh
pnpm lint
pnpm build
pnpm start
```

`pnpm start` serves the production build at `http://127.0.0.1:4173/tiktok-program-manager-portfolio/`. The static output is in `out/`. Serve it mounted at `/tiktok-program-manager-portfolio/` to test the same URL structure as GitHub Pages. No backend or environment secrets are required. Typography and portrait assets are served locally.

## Publication state

Prepared locally only. No remote repository created, no push, and no deployment performed. Publication awaits review of the concrete preview.

Intended new repository: `devashish1000/tiktok-program-manager-portfolio` (public metadata lookup returned 404 on September 14, 2026; recheck before creating).

Intended future URL: `https://devashish1000.github.io/tiktok-program-manager-portfolio/`. This is a GitHub Pages project site under the existing account, separate from its root portfolio. The URL is not live yet.

After explicit publication authorization: create that new repository, push this project only, enable GitHub Pages with GitHub Actions as its source, and manually run the included Pages workflow. The workflow has a repository-name guard and only runs on manual dispatch. It must not be copied to or dispatched from the original portfolio repository.

## Content and assets

- All achievements are user-confirmed, not independently audited. Exact employment titles and dates follow the supplied current résumé.
- HeadWell is presented as a project and TestFlight release; no public product demo is implied.
- Potential five-year cost avoidance remains labeled potential.
- Work summaries are self-reported professional experience, not fabricated employer artifacts.
- The résumé is the supplied September 14 PDF with the updated GitHub header.
- Portrait reused from the existing public portfolio. DM Sans is licensed under SIL OFL; license is included with the font.
- No TikTok affiliation or employment claim is made.

## Main files

`src/app/page.tsx`: page structure; `src/app/globals.css`: responsive design; `src/components/Header.tsx`: accessible mobile navigation; `src/components/Casework.tsx`: historical brief and hypothetical sample; `src/data/content.ts`: supported work and career content; `src/data/casework.ts`: illustrative framework and editorial boundaries; `public/Dev_Neupane_Resume.pdf`: downloadable résumé.
