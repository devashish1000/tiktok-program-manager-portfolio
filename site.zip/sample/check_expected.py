"""Independent fixed expected-value checks for the supplied demonstration fixture."""
import csv,json
from pathlib import Path
p=Path(__file__).resolve().parent
rows=list(csv.DictReader((p/'reviews.csv').open()))
r=json.loads((p/'results.json').read_text())
assert len(rows)==120
assert sum(x['period']=='baseline' and x['decision_a']!=x['decision_b'] for x in rows)==8
assert sum(x['period']=='rollout' and x['decision_a']!=x['decision_b'] for x in rows)==12
assert r['totals']['baseline']=={'reviewed':60,'disagreements':8,'rate_percent':13.33}
assert r['totals']['rollout']=={'reviewed':60,'disagreements':12,'rate_percent':20.0}
assert r['change_pp']==6.67
assert [(x['workflow'],x['change_pp']) for x in r['strata']]==[('appeals',20.0),('escalations',0.0),('general',0.0)]
assert r['rollout_taxonomy']=={'guidance_ambiguity':8,'needs_specialist_review':2,'version_mismatch':2}
assert r['capacity'][0]['required_minutes']==120 and r['capacity'][0]['shortfall_minutes']==30
assert r['capacity'][1]['required_minutes']==40 and r['capacity'][1]['shortfall_minutes']==0
assert r['synthetic'] is True
print('PASS: fixture counts, subgroup rates, taxonomy, percentage points and capacity arithmetic')
