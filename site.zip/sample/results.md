# Synthetic review: computed results

Invented demonstration data. Descriptive arithmetic only; no employer data, causal effect, or achieved operational result.

Disagreement: 8/60 baseline → 12/60 rollout (+6.67 percentage points).

| Workflow | Baseline | Rollout | Change (pp) |
|---|---:|---:|---:|
| appeals | 4/20 | 8/20 | +20.00 |
| escalations | 2/20 | 2/20 | +0.00 |
| general | 2/20 | 2/20 | +0.00 |

Rollout reason counts: guidance_ambiguity: 8, needs_specialist_review: 2, version_mismatch: 2

Capacity assumptions:
- appeals_followup: 120 required vs 90 available minutes; shortfall 30 minutes.
- specialist_escalations: 40 required vs 60 available minutes; shortfall 0 minutes.
