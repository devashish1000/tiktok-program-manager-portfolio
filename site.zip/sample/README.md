# Independent synthetic review-quality demonstration

All rows, reason labels, site names, periods, and capacity assumptions are invented for this demonstration. This is not TikTok or LinkedIn work, actual platform data, an executed rollout, or evidence of achieved business impact. The Python analysis has been executed; its arithmetic outputs are reproducible.

## Reproduce

Download this folder's reviews.csv, capacity.csv and analyze.py into one directory. With Python 3 installed, run:

```sh
python3 analyze.py
```

The script overwrites results.json and results.md in that same directory. No packages, network access or credentials are needed. Check results with `python3 check_expected.py`. CSV files and the script are the analytical inputs; the reason labels are authored taxonomy examples, not machine-generated or independently adjudicated findings.

## Dataset and definitions

There are 120 synthetic, independently paired review records: 60 baseline and 60 rollout. Each period has 20 general reviews, 20 appeals and 20 escalations. Disagreement means decision_a differs from decision_b; it does not establish which decision is correct. These equal-sized strata are a demonstration design, not a representative production sample. Aggregate results are descriptive of these rows only; there is no significance or causal claim. Each workflow maps to one site, so site and workflow effects cannot be separated.

Taxonomy: guidance_ambiguity = illustrative unclear-guidance flag; version_mismatch = illustrative policy-version flag; needs_specialist_review = illustrative escalation flag; agreement = matching decisions. Flags do not independently prove causes or severity. Capacity is a separate planning assumption: cases multiplied by assumed review minutes, compared with available minutes. Queues have different assumed skills; unused specialist minutes cannot be freely assigned to appeals.

## Computed observation

Disagreement is 8/60 (13.33%) in baseline and 12/60 (20%) in rollout, a 6.67-percentage-point increase. All four additional disagreements occur in the appeals stratum, which changes from 4/20 to 8/20. General and escalation disagreement counts remain unchanged. The rollout taxonomy has eight guidance flags, two version flags, and two specialist-review flags.

The appeals follow-up queue needs 120 minutes against 90 available: a 30-minute shortfall. Specialist escalation review needs 40 minutes against 60 available. Neither estimate is a measured staffing requirement.

## Proposed decision brief

**Recommendation:** request qualified specialist review of the two escalation flags first, and propose holding broader expansion of the affected appeals workflow while its eight disagreement cases are reviewed. The synthetic evidence supports targeted investigation, not a claim that policy caused the increase or a platform-wide rollback.

**Next action:** the policy owner would adjudicate guidance/version questions; operations would resolve the assumed 30-minute appeals gap through qualified capacity or an agreed schedule adjustment. A program owner would record the decision, owners, unresolved questions and follow-up trigger. Do not transfer specialist capacity without confirming eligibility.

**Checkpoint:** obtain adjudicated examples, clarify guidance where warranted, and perform a fresh comparable review before an accountable owner decides whether to expand, revise or continue the hold. Evaluate correctness and capacity alongside agreement. No numerical approval threshold is invented; responsible owners must set one appropriate to risk and evidence.

**Not executed:** adjudication, staffing changes, rollout pauses, policy changes, or production actions. This artifact demonstrates analysis and decision framing only.
