#!/usr/bin/env python3
"""Reproduce an entirely synthetic quality review; Python standard library only."""
import csv,json
from collections import defaultdict,Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parent
rows=list(csv.DictReader((ROOT/'reviews.csv').open()))
assert len({r['case_id'] for r in rows})==len(rows), 'Duplicate case IDs'
assert all(r['period'] in ('baseline','rollout') and r['decision_a'] in ('allow','remove') and r['decision_b'] in ('allow','remove') for r in rows)
groups=defaultdict(list)
for r in rows:groups[(r['period'],r['workflow'])].append(r)
strata=[]
for workflow in sorted({r['workflow'] for r in rows}):
 item={'workflow':workflow}
 for period in ('baseline','rollout'):
  subset=groups[period,workflow]; disagreements=sum(r['decision_a']!=r['decision_b'] for r in subset)
  item[period]={'reviewed':len(subset),'disagreements':disagreements,'rate_percent':round(100*disagreements/len(subset),2)}
 item['change_pp']=round(item['rollout']['rate_percent']-item['baseline']['rate_percent'],2);strata.append(item)
totals={}
for period in ('baseline','rollout'):
 subset=[r for r in rows if r['period']==period];n=sum(r['decision_a']!=r['decision_b'] for r in subset)
 totals[period]={'reviewed':len(subset),'disagreements':n,'rate_percent':round(100*n/len(subset),2)}
taxonomy=Counter(r['reason'] for r in rows if r['period']=='rollout' and r['decision_a']!=r['decision_b'])
capacity=[]
for r in csv.DictReader((ROOT/'capacity.csv').open()):
 available=int(r['available_minutes']);demand=int(r['planned_cases'])*int(r['minutes_per_case'])
 capacity.append({'queue':r['queue'],'available_minutes':available,'required_minutes':demand,'shortfall_minutes':max(0,demand-available)})
result={'synthetic':True,'disclosure':'Invented demonstration data. Descriptive arithmetic only; no employer data, causal effect, or achieved operational result.', 'totals':totals,'change_pp':round(totals['rollout']['rate_percent']-totals['baseline']['rate_percent'],2),'strata':strata,'rollout_taxonomy':dict(sorted(taxonomy.items())),'capacity':capacity}
(ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# Synthetic review: computed results','',result['disclosure'],'',f"Disagreement: {totals['baseline']['disagreements']}/{totals['baseline']['reviewed']} baseline → {totals['rollout']['disagreements']}/{totals['rollout']['reviewed']} rollout ({result['change_pp']:+.2f} percentage points).",'', '| Workflow | Baseline | Rollout | Change (pp) |','|---|---:|---:|---:|']
for r in strata:lines.append(f"| {r['workflow']} | {r['baseline']['disagreements']}/{r['baseline']['reviewed']} | {r['rollout']['disagreements']}/{r['rollout']['reviewed']} | {r['change_pp']:+.2f} |")
lines+=['','Rollout reason counts: '+', '.join(f'{k}: {v}' for k,v in sorted(taxonomy.items())), '', 'Capacity assumptions:']
for r in capacity:lines.append(f"- {r['queue']}: {r['required_minutes']} required vs {r['available_minutes']} available minutes; shortfall {r['shortfall_minutes']} minutes.")
(ROOT/'results.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(result,indent=2))
